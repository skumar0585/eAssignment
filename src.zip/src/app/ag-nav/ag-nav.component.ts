import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ag-nav',
  templateUrl: './ag-nav.component.html',
  styleUrls: ['./ag-nav.component.css']
})
export class AgNavComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
