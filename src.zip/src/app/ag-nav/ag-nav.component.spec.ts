import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgNavComponent } from './ag-nav.component';

describe('AgNavComponent', () => {
  let component: AgNavComponent;
  let fixture: ComponentFixture<AgNavComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgNavComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgNavComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
