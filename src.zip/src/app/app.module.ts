import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { AgNavComponent } from './ag-nav/ag-nav.component';
import { DatabindComponent } from './databind/databind.component';
import { GeolocationComponent } from './geolocation/geolocation.component';
import { TabsComponent } from './tabs/tabs.component';
import { JsondataComponent } from './jsondata/jsondata.component';
import { HttpModule } from '@angular/http';
import { TaboneComponent } from './tabs/tabone/tabone.component';
import { TabtwoComponent } from './tabs/tabtwo/tabtwo.component';
import { TabthreeComponent } from './tabs/tabthree/tabthree.component';
import { TabfourComponent } from './tabs/tabfour/tabfour.component';

import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [
    AppComponent,
    AgNavComponent,
    DatabindComponent,
    GeolocationComponent,
    TabsComponent,
    JsondataComponent,
    TaboneComponent,
    TabtwoComponent,
    TabthreeComponent,
    TabfourComponent,

  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    HttpModule,
    RouterModule.forRoot([
      {
        path: 'databind',
        component: DatabindComponent
      },
      {
        path: 'geolocation',
        component: GeolocationComponent
      },
      {
        path: 'tabs',
        component: TabsComponent
      },
      {
        path: 'jsondata',
        component: JsondataComponent
      }
    ])

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
