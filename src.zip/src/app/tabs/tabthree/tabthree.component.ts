import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tabthree',
  templateUrl: './tabthree.component.html',
  styleUrls: ['./tabthree.component.css']
})
export class TabthreeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
