import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TabthreeComponent } from './tabthree.component';

describe('TabthreeComponent', () => {
  let component: TabthreeComponent;
  let fixture: ComponentFixture<TabthreeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TabthreeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TabthreeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
