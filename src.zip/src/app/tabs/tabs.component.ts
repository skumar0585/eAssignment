import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tabs',
  templateUrl: './tabs.component.html',
  styleUrls: ['./tabs.component.css']
})
export class TabsComponent implements OnInit {

  isHome : boolean = true;
  isSpage : boolean = false;
  isAbout : boolean = false;
  isSvideo : boolean = false;

  constructor() { }

  ngOnInit() {
  }
  showHideHome(){
    this.isHome = true;
    this.isAbout = false;
    this.isSvideo = false;
    this.isSpage = false;
  }
  showHideSpage(){
    this.isHome = false;
    this.isAbout = false;
    this.isSvideo = false;
    this.isSpage = true;
  }
  showHideAbout(){
    this.isHome = false;
    this.isAbout = true;
    this.isSvideo = false;
    this.isSpage = false;
  }
  showHideSvideo(){
    this.isHome = false;
    this.isAbout = false;
    this.isSvideo = true;
    this.isSpage = false;
  }

}
