import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TabtwoComponent } from './tabtwo.component';

describe('TabtwoComponent', () => {
  let component: TabtwoComponent;
  let fixture: ComponentFixture<TabtwoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TabtwoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TabtwoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
