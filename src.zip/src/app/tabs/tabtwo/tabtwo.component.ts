import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tabtwo',
  templateUrl: './tabtwo.component.html',
  styleUrls: ['./tabtwo.component.css']
})
export class TabtwoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
