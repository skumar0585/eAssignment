import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tabfour',
  templateUrl: './tabfour.component.html',
  styleUrls: ['./tabfour.component.css']
})
export class TabfourComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
