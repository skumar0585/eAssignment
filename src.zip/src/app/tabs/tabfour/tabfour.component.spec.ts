import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TabfourComponent } from './tabfour.component';

describe('TabfourComponent', () => {
  let component: TabfourComponent;
  let fixture: ComponentFixture<TabfourComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TabfourComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TabfourComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
