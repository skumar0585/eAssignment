import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tabone',
  templateUrl: './tabone.component.html',
  styleUrls: ['./tabone.component.css']
})
export class TaboneComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
