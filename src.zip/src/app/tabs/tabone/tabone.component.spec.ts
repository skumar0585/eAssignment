import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TaboneComponent } from './tabone.component';

describe('TaboneComponent', () => {
  let component: TaboneComponent;
  let fixture: ComponentFixture<TaboneComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TaboneComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TaboneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
